UnminedCustomMarkers = {
    "isEnabled": true,
    "markers": []
}
